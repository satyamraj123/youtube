
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:youtube/Login_page.dart';
import 'package:youtube/home_page.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  var _isnit = true;
  var isLoading = false;
  var _isLogin = false;
  var prefs;
  @override
  Future<void> didChangeDependencies() async {
    if (_isnit) {
      setState(() {
        isLoading = true;
      });
      prefs = await SharedPreferences.getInstance();
      if (prefs.containsKey('userAuth')) {
        _isLogin = true;
      }else{
        _isLogin=false;
      }
      
    }
    setState(() {
        isLoading = false;
      });
      if(_isLogin){
        !isLoading?
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (ctx)=>HomePage())):null;
      }else{
        !isLoading?
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (ctx)=>LoginPage())):null;
      }
    _isnit = false;
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Container(height:300,width:300,
    color: Colors.green,)
    );
  }
}
