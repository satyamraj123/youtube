import 'package:flutter/material.dart';

import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class CategoryItem extends StatefulWidget {
  final data;
  final i;
  CategoryItem(this.data, this.i);
  @override
  _CategoryItemState createState() => _CategoryItemState();
}

class _CategoryItemState extends State<CategoryItem> {
 YoutubePlayerController _controller = YoutubePlayerController(
    initialVideoId: 'FtQP_rWJipc&t=1s',
    flags: YoutubePlayerFlags(
        autoPlay: true,
        mute: true,
    ),
);
  var _isExpanded = false;
  var _isPlay = false;
  @override
  Widget build(BuildContext context) {
    
    return Container(
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.only(left: 20, right: 20),
      decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(width: 1),
              right: BorderSide(width: 1),
              left: BorderSide(width: 1),
              top: BorderSide(width: 1)),
          borderRadius: BorderRadius.circular(20)),
      height: _isExpanded ? 508 : 328,
      width: 300,
      child: Column(
        children: <Widget>[
          SizedBox(height: 20),
          Card(
            elevation: 12,
            child: Container(
                height: 180,
                width: 330,
                alignment: Alignment.centerLeft,
                child: _isPlay
                    ? YoutubePlayer(
                        controller:_controller ,
                        )
                    : GestureDetector(
                        onTap: () {
                          setState(() {
                            _isPlay = true;
                          });
                        },
                        child: Image.network(
                          widget.data.items[widget.i].imageUrl,
                          fit: BoxFit.fill,
                          filterQuality: FilterQuality.low,
                          height: 180,
                          width: 330,
                        ),
                      )),
          ),
          SizedBox(height: 15),
          Container(
            height: _isExpanded ? 230 : 50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  height: _isExpanded ? 230 : 50,
                  width: 250,
                  child: Text(
                    "Description - " + widget.data.items[widget.i].description,
                    overflow: TextOverflow.fade,
                  ),
                ),
                IconButton(
                    onPressed: () {
                      setState(() {
                        _isExpanded = !_isExpanded;
                      });
                    },
                    icon: Icon(
                        _isExpanded ? Icons.expand_less : Icons.expand_more)),
              ],
            ),
          )
        ],
      ),
    );
  }
}
