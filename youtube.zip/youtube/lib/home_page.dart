import 'package:flutter/material.dart';
import 'package:youtube/Categories_page.dart';
import 'package:youtube/profile_page.dart';
class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentindex = 0;

  final List<Widget> pages = [
  CategoriesPage(),
    CategoriesPage(),
    CategoriesPage(),
    ProfilePage()
  ];

  void changePage(int index) {
    setState(() {
      _currentindex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        
        appBar: _currentindex == 3
            ? PreferredSize(
              preferredSize: Size.fromHeight(70),
                          child: AppBar(
                  title: Column(
                    children: <Widget>[
                      SizedBox(height: 30,),
                      Center(child: Text("Name",style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),)),
                    ],
                  ),
                  actions: <Widget>[Icon(Icons.settings,size: 40,)],
                ),
            )
            : PreferredSize(
              preferredSize: Size.fromHeight(70),
                          child: AppBar(
                
                  title: TextField(),
                  leading: Container(
                    color:Colors.grey,child: Icon(Icons.camera_alt,size: 40,),),
                  actions: <Widget>[
                    Icon(Icons.search,size: 50,),
                    SizedBox(width:30),
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.black,
                      child: Icon(
                        Icons.account_circle,size: 50,),
                    )
                  ],
                ),
            ),
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.green,

            unselectedItemColor: Colors.white,
            selectedItemColor: Colors.black,
            currentIndex: _currentindex,
            onTap: changePage,
            items: [
              BottomNavigationBarItem(backgroundColor: Colors.green,
                title: Text(""), icon: Icon(Icons.home)),
              BottomNavigationBarItem(
                  title: Text(""), icon: Icon(Icons.trending_up)),
              BottomNavigationBarItem(
                  title: Text(""), icon: Icon(Icons.live_tv)),
              BottomNavigationBarItem(
                  title: Text(""), icon: Icon(Icons.account_circle)),
            ]),
        body: pages[_currentindex],
      );
  }
}