import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:youtube/category_item.dart';
import 'categories_model.dart';

class CategoriesPage extends StatefulWidget {
  @override
  _CategoriesPageState createState() => _CategoriesPageState();
}

class _CategoriesPageState extends State<CategoriesPage> {
  

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      child: Consumer<CategoriesList>(
        builder: (ctx, data, _) => ListView.builder(
          padding: EdgeInsets.only(bottom: 10,top: 10),
          itemCount: data.items.length,
          itemBuilder: (ctx, i) => CategoryItem(data,i)
        ),
      ),
    );
  }
}
