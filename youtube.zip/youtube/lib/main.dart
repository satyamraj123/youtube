import 'package:flutter/material.dart';
import 'package:youtube/Categories_page.dart';
import 'package:provider/provider.dart';
import 'package:youtube/categories_model.dart';
import 'package:youtube/profile_page.dart';
import 'package:youtube/splash_screen.dart';

void main() {
  runApp(ChangeNotifierProvider(
      create: (context) => CategoriesList(), child: MyApp()));
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
          primaryColor: Colors.green,
          accentColor: Colors.greenAccent,
          bottomAppBarColor: Colors.green,
          bottomAppBarTheme: BottomAppBarTheme(color: Colors.green)),
      home: SplashScreen(),
    );
  }
}
